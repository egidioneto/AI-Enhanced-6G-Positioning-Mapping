RPLIDAR Public SDK v1.8.0 Release Note
======================================

- [new feature] support baudrate 57600
- [bugfix] TCP channel doesn't work
- [improvement] Print warning messages when deprecated APIs are called
