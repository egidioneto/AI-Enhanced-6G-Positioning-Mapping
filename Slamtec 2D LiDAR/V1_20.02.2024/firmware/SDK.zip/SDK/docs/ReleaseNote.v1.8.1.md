RPLIDAR Public SDK v1.8.1 Release Note
======================================

- [new feature] support baudrate 1382400
- [improvement] imporve angular accuracy for ultra capsuled scan points
