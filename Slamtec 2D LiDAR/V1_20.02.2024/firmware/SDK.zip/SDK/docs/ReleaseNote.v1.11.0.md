RPLIDAR Public SDK v1.11.0 Release Note
======================================

- [new feature] support 256000 baudrate on macOS
- [improvement] better support for S1 in framegrabber
- [improvement] default tty device is set to /dev/tty.SLAB_USBtoUART instead of /dev/ttyUSB0
